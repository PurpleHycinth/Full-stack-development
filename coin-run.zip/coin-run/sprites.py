sprite_images = ["player-left.gif",
                 "player-right.gif",
                 "jungle.gif",
                 "gold.gif", "enemy-left.gif", "enemy-right.gif"]
