# Tetris
Tetris game made with the Pygame library in Python.
There are 3 difficulty modes: 
1 - EASY 
2 - MEDIUM 
3 - DIFFICULT 

Access Keys:- 

KEY UP - TO CHANGE THE POSITION OF BLOCK
KEY DOWN - TO MAKE THE BLOCK FALL
KEY LEFT - TO MOVE BLOCK LEFT 
KEY RIGHT - TO MOVE BLOCK RIGHT 

R - TO REFRESH AND RESTART GAME LEVEL
P - TO PAUSE OR PLAY THE GAME

## Authors

* **Gaurika C**
* **Swarali D**
