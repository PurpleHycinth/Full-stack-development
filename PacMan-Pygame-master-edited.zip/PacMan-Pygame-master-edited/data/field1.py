import os
from gate import Gate

class GameEngine:
    def __init__(self):
        self.levelPelletRemaining = 0
        self.levelObjects = [[LevelObject("empty") for j in range(32)] for i in range(28)]
        self.movingObjectPacman = MovingObject("Pacman")
        self.gate = Gate()
        self.levelObjectNamesBlocker = ["wall", "cage"]
        self.levelObjectNamesPassable = ["empty", "pellet", "powerup"]
        self.challenge_active = False

    def levelGenerate(self, level):
        pathCurrentDir = os.path.dirname(__file__)
        pathRelDir = "../resource/level{}.txt".format(level)
        pathAbsDir = os.path.join(pathCurrentDir, pathRelDir)

        levelFile = open(pathAbsDir, encoding="utf-8")
        levelLineNo = 0

        for levelLine in levelFile.readlines():
            levelLineSplit = list(levelLine)

            for i in range(28):
                if levelLineSplit[i] == "_":
                    self.levelObjects[i][levelLineNo].name = "empty"
                elif levelLineSplit[i] == "#":
                    self.levelObjects[i][levelLineNo].name = "wall"
                elif levelLineSplit[i] == ".":  # score pellet
                    self.levelObjects[i][levelLineNo].name = "pellet"

                    # checking how many pellets are in the level
                    if self.levelObjects[i][levelLineNo].isDestroyed == False:
                        self.levelPelletRemaining += 1
                    else:
                        pass
                elif levelLineSplit[i] == "*":  # power pellet
                    self.levelObjects[i][levelLineNo].name = "powerup"

                    # checking how many pellets are in the level
                    if self.levelObjects[i][levelLineNo].isDestroyed == False:
                        self.levelPelletRemaining += 1
                    else:
                        pass
                elif levelLineSplit[i] == "@":
                    self.levelObjects[i][levelLineNo].name = "empty"
                    self.movingObjectPacman.coordinateRel[0] = i
                    self.movingObjectPacman.coordinateRel[1] = levelLineNo
                    self.movingObjectPacman.coordinateAbs[0] = i * 4
                    self.movingObjectPacman.coordinateAbs[1] = levelLineNo * 4

            levelLineNo += 1

        levelFile.close()

    def check_collision(self):
        if self.pacman.touches(self.gate) and not self.challenge_active:
            self.start_challenge()

    def open_gate(self):
        # Handle the gate opening logic
        self.challenge_active = False
        self.gate.open()

    def game_loop(self):
        # Your game loop that checks for collisions and runs the game

        # Pseudo code:
        while True:
            self.check_collision()
            # Other game logic here
            
    def encounterFixed(self, x, y):
        if self.levelObjects[x][y].name == "empty":
            return "empty"
        elif self.levelObjects[x][y].name == "pellet":
            return "pellet"
        elif self.levelObjects[x][y].name == "powerup":
            return "powerup"

    def encounterMoving(self, x, y):    # abs coord.

        result = "alive"    # default return

        for i in range(4):  # check if pacman encountered ghost
            m = self.movingObjectGhosts[i].coordinateAbs[0] # ghost's x coord.
            n = self.movingObjectGhosts[i].coordinateAbs[1] # ghost's y coord.

            if self.movingObjectGhosts[i].isActive == True and self.movingObjectGhosts[i].isCaged == False:
                if (m-3 < x < m+3) and (n-3 < y < n+3):   # check x coord. and y coord. parallelly, this is little bit benign determine (we can use +-4)
                    result = "dead"
                else:
                    pass
            else:
                pass
        
        return result
    
    def loopFunction(self):
        self.movingObjectPacman.MoveNext(self)
        self.movingObjectPacman.MoveCurrent(self)

class LevelObject(object):
    def __init__(self, name):
        self.reset(name)

    def reset(self, name):
        self.name = name
        self.isDestroyed = False

class MovingObject(object):
    def __init__(self, name):
        self.reset(name)


    def reset(self, name):
        self.name = name
        self.isActive = False       # check this object is an active ghost (not used for pacman)
        self.isCaged = True         # check this object is caged (only for ghost)
        self.dirCurrent = "Left"    # current direction, if cannot move w/ dirNext, the object will proceed this direction
        self.dirNext = "Left"       # the object will move this direction if it can
        self.dirOpposite = "Right"  # opposite direction to current direction, used for ghost movement determine
        self.dirEdgePassed = False  # check the object passed one of field1 edges
        self.coordinateRel = [0, 0] # Relative Coordinate, check can the object move given direction
        self.coordinateAbs = [0, 0] # Absolute Coordinate, use for widget(image) and object encounters


    def MoveNext(self, GameEngine):
        ## this function will determine pacman can move with given direction or not

        if self.dirNext == self.dirCurrent: # in this case, no action is required
            pass
        
        elif self.coordinateAbs[0] % 4 != 0: # if the object is moving, prevent to change its direction
            pass

        elif self.coordinateAbs[1] % 4 != 0: # if the object is moving, prevent to change its direction
            pass

        else:
            if self.dirNext == "Left":  # check the direction first

                if self.coordinateRel[0] == 0: # at left edge, allow to change direction without checking (prevent index error)
                    self.dirCurrent = "Left"

                else:
                    nextObject = GameEngine.levelObjects[self.coordinateRel[0]-1][self.coordinateRel[1]] # levelObject placed left of this object

                    # check the levelObject and allow movingObject to change its current direction
                    if nextObject.name in GameEngine.levelObjectNamesPassable:
                        self.dirCurrent = "Left"
                    elif nextObject.name in GameEngine.levelObjectNamesBlocker:
                        pass
                

            elif self.dirNext == "Right":

                if self.coordinateRel[0] == 27: # at right edge, allow to change direction without checking (prevent index error)
                    self.dirCurrent = "Right"

                else:
                    nextObject = GameEngine.levelObjects[self.coordinateRel[0]+1][self.coordinateRel[1]] # levelObject placed right of this object

                    # check the levelObject and allow movingObject to change its current direction
                    if nextObject.name in GameEngine.levelObjectNamesPassable:
                        self.dirCurrent = "Right"
                    elif nextObject.name in GameEngine.levelObjectNamesBlocker:
                        pass


            elif self.dirNext == "Down":

                if self.coordinateRel[1] == 31: # at bottom edge, allow to change direction without checking (prevent index error)
                    self.dirCurrent = "Down"

                else:
                    nextObject = GameEngine.levelObjects[self.coordinateRel[0]][self.coordinateRel[1]+1] # levelObject placed down of this object

                    # check the levelObject and allow movingObject to change its current direction
                    if nextObject.name in GameEngine.levelObjectNamesPassable:
                        self.dirCurrent = "Down"
                    elif nextObject.name in GameEngine.levelObjectNamesBlocker:
                        pass


            elif self.dirNext == "Up":

                if self.coordinateRel[1] == 0: # at top edge, allow to change direction without checking (prevent index error)
                    self.dirCurrent = "Up"

                else:
                    nextObject = GameEngine.levelObjects[self.coordinateRel[0]][self.coordinateRel[1]-1] # levelObject placed up of this object

                    # check the levelObject and allow movingObject to change its current direction
                    if nextObject.name in GameEngine.levelObjectNamesPassable:
                        self.dirCurrent = "Up"
                    elif nextObject.name in GameEngine.levelObjectNamesBlocker:
                        pass


    def MoveCurrent(self, GameEngine):

        if self.dirCurrent == "Left":

            if self.coordinateAbs[0] == 0: # at left edge, move to right edge
                self.coordinateAbs[0] = 27*4 + 3
                self.coordinateRel[0] = 28
                self.dirEdgePassed = True
            
            else:
                nextObject = GameEngine.levelObjects[self.coordinateRel[0]-1][self.coordinateRel[1]] # levelObject placed left of this object
                # check the levelObject and allow movingObject to move its current direction
                if nextObject.name in GameEngine.levelObjectNamesPassable:
                    self.coordinateAbs[0] -= 1 # adjust current coordinate
                    if self.coordinateAbs[0] % 4 == 0: # check the object reaches a grid coordinate (coordinateRel)
                        self.coordinateRel[0] -= 1

                elif nextObject.name in GameEngine.levelObjectNamesBlocker:
                    self.dirCurrent = "Stop"


        elif self.dirCurrent == "Right":

            if self.coordinateAbs[0] == 27*4:  # at right edge, move to left edge
                self.coordinateAbs[0] = -3
                self.coordinateRel[0] = -1
                self.dirEdgePassed = True

            else:
                nextObject = GameEngine.levelObjects[self.coordinateRel[0]+1][self.coordinateRel[1]] # levelObject placed right of this object
                # check the levelObject and allow movingObject to move its current direction
                if nextObject.name in GameEngine.levelObjectNamesPassable:
                    self.coordinateAbs[0] += 1  # adjust current coordinate
                    if self.coordinateAbs[0] % 4 == 0: # check the object reaches a grid coordinate (coordinateRel)
                        self.coordinateRel[0] += 1

                elif nextObject.name in GameEngine.levelObjectNamesBlocker:
                    self.dirCurrent = "Stop"


        elif self.dirCurrent == "Down":

            if self.coordinateAbs[1] == 31*4:  # at bottom edge, move to top edge
                self.coordinateAbs[1] = -3
                self.coordinateRel[1] = -1
                self.dirEdgePassed = True

            else:
                nextObject = GameEngine.levelObjects[self.coordinateRel[0]][self.coordinateRel[1]+1] # levelObject placed down of this object
                # check the levelObject and allow movingObject to move its current direction
                if nextObject.name in GameEngine.levelObjectNamesPassable:
                    self.coordinateAbs[1] += 1  # adjust current coordinate
                    if self.coordinateAbs[1] % 4 == 0: # check the object reaches a grid coordinate (coordinateRel)
                        self.coordinateRel[1] += 1

                elif nextObject.name in GameEngine.levelObjectNamesBlocker:
                    self.dirCurrent = "Stop"


        elif self.dirCurrent == "Up":

            if self.coordinateAbs[1] == 0:  # at top edge, move to bottom edge
                self.coordinateAbs[1] = 31*4 + 3
                self.coordinateRel[1] = 32
                self.dirEdgePassed = True

            else:
                nextObject = GameEngine.levelObjects[self.coordinateRel[0]][self.coordinateRel[1]-1] # levelObject placed up of this object
                # check the levelObject and allow movingObject to move its current direction
                if nextObject.name in GameEngine.levelObjectNamesPassable:
                    self.coordinateAbs[1] -= 1  # adjust current coordinate
                    if self.coordinateAbs[1] % 4 == 0: # check the object reaches a grid coordinate (coordinateRel)
                        self.coordinateRel[1] -= 1

                elif nextObject.name in GameEngine.levelObjectNamesBlocker:
                    self.dirCurrent = "Stop"


        elif self.dirCurrent == "Stop":
            pass


gameEngine = GameEngine()
