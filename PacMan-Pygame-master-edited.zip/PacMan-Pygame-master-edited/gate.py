import random

class Gate:
    def __init__(self):
        self.is_open = False  # Gate is initially closed

    def open(self):
        self.is_open = True

    def close(self):
        self.is_open = False

    def is_closed(self):
        return not self.is_open

